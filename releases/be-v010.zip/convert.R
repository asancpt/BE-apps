knitr::knit2html("report.Rmd", 
                 "result/report.html", 
                 options = c("toc", "mathjax"))

knitr::knit2html("raw_data.Rmd", 
                 "result/raw_data.html", 
                 options = c("toc", "mathjax"))
